export const BY_COUNTRYCODE = 'countrycode';
export const BY_RECT = 'rect';
export const BY_CIRCLE = 'circle';
export const BY_PROXIMITY = 'proximity';
export const BY_PLACE = 'place';
