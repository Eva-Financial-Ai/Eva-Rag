## Requirements
Make sure you run at least Node 18.0.0

## Demo

To run the demo:
1) Put "API_KEY" in demo/index.html
2) Execute "npm run start:demo"